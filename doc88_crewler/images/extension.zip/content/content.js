/**
 * Doc88 PDF Generator - Content Script
 * 核心邏輯：監測、載入、生成 PDF
 */

// ==================== State Management ====================
const State = {
  INIT: 'init',
  WAITING_UNLOCK: 'waiting_unlock',
  UNLOCKED: 'unlocked',
  LOADING: 'loading',
  LOADING_PAUSED: 'loading_paused',
  READY: 'ready',
  GENERATING: 'generating',
  ERROR: 'error'
};

class Doc88Controller {
  constructor() {
    this.state = State.INIT;
    this.isUnlocked = false;
    this.isLoading = false;
    this.shouldStopLoading = false;
    this.currentPage = 0;
    this.totalPages = 0;
    this.loadedPagesCount = 0; // 成功載入的頁面計數
    this.failedPages = []; // 載入超時的頁面索引
    this.canvases = [];
    this.observer = null;
    this.notification = null;
    this.quality = 1.0; // Default high quality

    // Focus mode (hide non-document elements)
    this.focusModeEnabled = false;
    this.hiddenElements = [];
    this.originalBodyBg = '';
    this.originalBodyBgColor = '';
    this.originalContainerBg = '';
  }

  // ==================== State Transitions ====================
  setState(newState) {
    this.state = newState;
    this.notifyStateChange();
  }

  notifyStateChange() {
    // 將狀態映射到 CSS 類名
    const statusMap = {
      [State.INIT]: 'loading',
      [State.WAITING_UNLOCK]: 'waiting',
      [State.UNLOCKED]: 'ready',
      [State.LOADING]: 'loading',
      [State.LOADING_PAUSED]: 'waiting',
      [State.READY]: 'ready',
      [State.GENERATING]: 'loading',
      [State.ERROR]: 'error'
    };

    chrome.runtime.sendMessage({
      action: 'statusUpdate',
      status: statusMap[this.state] || 'waiting',
      text: this.getStatusText(),
      state: this.state
    });
  }

  getStatusText() {
    const messages = {
      [State.INIT]: chrome.i18n.getMessage('loading'),
      [State.WAITING_UNLOCK]: chrome.i18n.getMessage('waitingForUnlock'),
      [State.UNLOCKED]: chrome.i18n.getMessage('unlockComplete'),
      [State.LOADING]: chrome.i18n.getMessage('loading'),
      [State.READY]: chrome.i18n.getMessage('complete'),
      [State.GENERATING]: chrome.i18n.getMessage('generating'),
      [State.ERROR]: chrome.i18n.getMessage('error')
    };
    return messages[this.state] || '';
  }

  // ==================== Page Type Detection ====================
  isDocumentViewPage() {
    // 檢測是否為文件瀏覽頁面（而非搜尋頁、列表頁等）
    // 必須同時具備以下特有元素：
    const pageContainer = document.querySelector('#pageContainer');
    const outerPages = document.querySelectorAll('.outer_page');
    const canvases = document.querySelectorAll('canvas.inner_page');

    // 至少要有 pageContainer 和一些 outer_page 結構
    const hasDocumentStructure = pageContainer && outerPages.length > 0;

    // 排除搜尋頁面（通常有搜尋框和結果列表）
    const isSearchPage = document.querySelector('.search-results, .doc-list, #search-box, .list-wrap');

    return hasDocumentStructure && !isSearchPage;
  }

  // ==================== Element Detection ====================
  detectContinueButton() {
    const continueBtn = document.querySelector('#continue_page');
    return continueBtn && continueBtn.offsetParent !== null;
  }

  detectPageContainer() {
    return document.querySelector('#pageContainer');
  }

  detectCurrentPage() {
    // 從導航條的輸入框讀取當前頁碼
    const pageInput = document.querySelector('#pageNumInput');
    if (pageInput && pageInput.value) {
      const page = parseInt(pageInput.value);
      if (!isNaN(page) && page > 0) {
        return page;
      }
    }

    // Fallback: count visible canvases
    const visibleCanvases = document.querySelectorAll('#pageContainer canvas.inner_page');
    return visibleCanvases.length;
  }

  detectTotalPages() {
    // 從導航條的文本讀取總頁數（格式："[當前頁碼] / 總頁數"）
    const pageInput = document.querySelector('#pageNumInput');
    if (pageInput && pageInput.parentElement) {
      const parentText = pageInput.parentElement.textContent || '';
      // 匹配 "/ 數字" 格式
      const match = parentText.match(/\/\s*(\d+)/);
      if (match) {
        const total = parseInt(match[1]);
        if (!isNaN(total) && total > 0) {
          return total;
        }
      }
    }

    // Fallback: estimate from page container children
    const pageContainer = this.detectPageContainer();
    if (pageContainer) {
      const outerPages = pageContainer.querySelectorAll('.outer_page');
      return outerPages.length;
    }

    return 0;
  }

  // ==================== Canvas Rendering Detection ====================
  isCanvasRendered(canvas, pageNumber = 0) {
    if (!canvas || canvas.width === 0 || canvas.height === 0) {
      return false;
    }

    try {
      // Set willReadFrequently for performance optimization
      const ctx = canvas.getContext('2d', { willReadFrequently: true });

      // Try to read pixel data
      try {
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;

        const sampleRate = 100;
        let totalSamples = 0;
        let whitePixels = 0;
        let blackPixels = 0;
        let transparentPixels = 0;
        let coloredPixels = 0; // Non-white, non-black, non-transparent

        for (let i = 0; i < data.length; i += 4 * sampleRate) {
          const r = data[i];
          const g = data[i + 1];
          const b = data[i + 2];
          const a = data[i + 3];

          totalSamples++;

          if (a === 0) {
            // Fully transparent
            transparentPixels++;
          } else if (r <= 10 && g <= 10 && b <= 10) {
            // Black or near-black (unloaded page indicator)
            blackPixels++;
          } else if (r >= 245 && g >= 245 && b >= 245) {
            // White or near-white
            whitePixels++;
          } else {
            // Has actual color content
            coloredPixels++;
          }
        }

        // Calculate percentages
        const blackRatio = blackPixels / totalSamples;
        const whiteRatio = whitePixels / totalSamples;
        const transparentRatio = transparentPixels / totalSamples;
        const coloredRatio = coloredPixels / totalSamples;

        // FAIL CONDITIONS - page is NOT properly loaded:
        if (blackRatio > 0.8) return false;
        if (transparentRatio > 0.8) return false;
        if (whiteRatio > 0.95 && coloredPixels < 5) return false;

        // SUCCESS: Has meaningful colored content
        if (coloredPixels > 10) return true;
        if (whiteRatio > 0.7 && coloredPixels > 2) return true;

        return false;

      } catch (securityError) {
        // Canvas is tainted (cross-origin) - cannot read pixels
        return false; // Be conservative - mark as failed to trigger retry
      }
    } catch (e) {
      // On error, mark as failed to trigger retry mechanism
      return false;
    }
  }

  async waitForLoadingIndicators(outerPage, pageNumber, timeout = 10000) {
    const startTime = Date.now();
    let lastProgressText = '';
    let progressStableCount = 0;
    const STABLE_THRESHOLD = 3;

    while (Date.now() - startTime < timeout) {
      const allImages = outerPage.querySelectorAll('img');
      let hasLoadingImage = false;

      for (const img of allImages) {
        if (img.offsetParent !== null) {
          const src = img.src?.toLowerCase() || '';
          const alt = img.alt?.toLowerCase() || '';
          const className = img.className?.toLowerCase() || '';

          if (src.includes('loading') || src.includes('spinner') || src.includes('wait') ||
              alt.includes('loading') || alt.includes('載入') || alt.includes('加载') ||
              className.includes('loading') || className.includes('spinner')) {
            hasLoadingImage = true;
            break;
          }
        }
      }

      const allElements = outerPage.querySelectorAll('*');
      let currentProgressText = '';
      let hasVisibleProgress = false;

      for (const elem of allElements) {
        if (elem.offsetParent !== null) {
          const text = elem.textContent?.trim() || '';
          const computedStyle = window.getComputedStyle(elem);
          const isVisible = computedStyle.display !== 'none' &&
                           computedStyle.visibility !== 'hidden' &&
                           computedStyle.opacity !== '0';

          if (isVisible && text) {
            const percentMatch = text.match(/^\d{1,3}%$/);
            const loadingMatch = text.match(/載入|loading|加载/i);

            if (percentMatch) {
              currentProgressText = text;
              hasVisibleProgress = true;
              break;
            } else if (loadingMatch && text.length < 50) {
              hasVisibleProgress = true;
              break;
            }
          }
        }
      }

      const animatedElements = outerPage.querySelectorAll('[class*="spin"], [class*="rotate"], [class*="loading"], [class*="loader"]');
      let hasAnimation = false;

      for (const elem of animatedElements) {
        if (elem.offsetParent !== null) {
          const computedStyle = window.getComputedStyle(elem);
          if (computedStyle.animation !== 'none' || computedStyle.transform.includes('rotate')) {
            hasAnimation = true;
            break;
          }
        }
      }

      if (currentProgressText && currentProgressText === lastProgressText) {
        progressStableCount++;
      } else {
        progressStableCount = 0;
        lastProgressText = currentProgressText;
      }

      const hasSpinner = hasLoadingImage || hasAnimation;
      const isProgressStable = progressStableCount >= STABLE_THRESHOLD;

      if (!hasSpinner && !hasVisibleProgress) return true;
      if (!hasSpinner && isProgressStable) return true;

      await new Promise(resolve => setTimeout(resolve, 200));
    }

    return false;
  }

  async waitForCanvasLoad(canvas, pageNumber = 0, timeout = 10000) {
    const startTime = Date.now();
    const quickCheckTime = 3000;
    let attempts = 0;
    let isBlankPage = false;
    let domChanges = [];

    const outerPage = canvas.closest('.outer_page');
    if (outerPage) {
      await this.waitForLoadingIndicators(outerPage, pageNumber, 5000);
    }

    const domObserver = new MutationObserver((mutations) => {
      mutations.forEach(mutation => {
        if (mutation.type === 'attributes' || mutation.type === 'childList') {
          domChanges.push({ timestamp: Date.now() - startTime });
        }
      });
    });

    if (outerPage) {
      domObserver.observe(outerPage, { attributes: true, childList: true, subtree: true });
    }

    while (Date.now() - startTime < timeout) {
      attempts++;
      const elapsed = Date.now() - startTime;

      if (this.isCanvasRendered(canvas, pageNumber)) {
        domObserver.disconnect();
        return true;
      }

      if (elapsed >= quickCheckTime && !isBlankPage) {
        const hasValidDimensions = canvas.width > 100 && canvas.height > 100;
        if (hasValidDimensions && domChanges.length === 0) {
          isBlankPage = true;
          domObserver.disconnect();
          return true;
        }
      }

      await new Promise(resolve => setTimeout(resolve, 200));
    }

    domObserver.disconnect();
    return false;
  }

  // ==================== Page Loading ====================
  async loadAllPages() {
    this.setState(State.LOADING);
    this.isLoading = true;
    this.shouldStopLoading = false;

    // 啟用專注模式：隱藏文件容器以外的所有元素
    this.enableFocusMode();

    this.showNotification(chrome.i18n.getMessage('loading'));

    // 獲取所有頁面容器
    const outerPages = Array.from(document.querySelectorAll('#pageContainer .outer_page'));

    if (outerPages.length === 0) {
      this.setState(State.ERROR);
      return;
    }

    this.totalPages = outerPages.length;
    this.loadedPagesCount = 0; // 重置載入計數
    this.failedPages = []; // 重置失敗頁面列表

    // 逐頁滾動和載入
    for (let i = 0; i < outerPages.length && !this.shouldStopLoading; i++) {
      const outerPage = outerPages[i];

      // 滾動到當前頁面
      outerPage.scrollIntoView({ behavior: 'smooth', block: 'center' });

      // 等待滾動完成
      await new Promise(resolve => setTimeout(resolve, 300));

      // 從導航條讀取實際的當前頁碼和總頁數
      const currentPage = this.detectCurrentPage();
      const totalPages = this.detectTotalPages();

      // 更新通知（顯示進度）
      const progressMsg = chrome.i18n.getMessage('loadingPageProgress', [
        currentPage.toString(),
        totalPages.toString()
      ]);
      this.showNotification(progressMsg || `載入第 ${currentPage}/${totalPages} 頁`);

      // 更新頁面資訊
      this.currentPage = currentPage;
      this.totalPages = totalPages;
      this.updatePageInfo();

      // 更新進度
      chrome.runtime.sendMessage({
        action: 'progressUpdate',
        current: currentPage,
        total: totalPages
      });

      // 查找當前頁的 Canvas
      const canvas = outerPage.querySelector('canvas.inner_page');

      if (canvas) {
        // 等待 Canvas 渲染完成
        const isLoaded = await this.waitForCanvasLoad(canvas, currentPage, 8000);

        if (isLoaded) {
          this.loadedPagesCount++;
        } else {
          this.failedPages.push(i); // 記錄失敗頁面的索引
        }

        // 發送載入統計到 popup
        chrome.runtime.sendMessage({
          action: 'loadingStats',
          loadedPages: this.loadedPagesCount,
          currentPage: currentPage,
          totalPages: totalPages
        });

        // 每載入一頁後稍微等待，確保穩定
        await new Promise(resolve => setTimeout(resolve, 200));
      }
    }

    // 載入完成後滾動到頂部
    window.scrollTo({ top: 0, behavior: 'smooth' });
    await new Promise(resolve => setTimeout(resolve, 500));

    // 收集所有已載入的 Canvas
    this.canvases = Array.from(document.querySelectorAll('#pageContainer canvas.inner_page'));

    this.isLoading = false;
    this.totalPages = this.canvases.length;
    this.currentPage = this.totalPages;
    this.updatePageInfo();

    if (this.shouldStopLoading) {
      this.setState(State.LOADING_PAUSED);
      this.showNotification(`已停止：已確認載入 ${this.loadedPagesCount} 頁`);
    } else {
      this.setState(State.READY);
      this.hideNotification();
      chrome.runtime.sendMessage({
        action: 'loadingComplete',
        hasIncomplete: this.failedPages.length > 0,
        failedCount: this.failedPages.length
      });
    }

    // 專注模式已在開始時啟用，載入完成後保持啟用狀態
  }

  stopLoading() {
    this.shouldStopLoading = true;
  }

  async retryNextFailedPage() {
    if (this.failedPages.length === 0) {
      chrome.runtime.sendMessage({ action: 'allPagesLoaded' });
      return;
    }

    // 取得第一個失敗頁面的索引
    const pageIndex = this.failedPages.shift();
    const outerPages = document.querySelectorAll('#pageContainer .outer_page');

    if (pageIndex >= outerPages.length) {
      return;
    }

    const outerPage = outerPages[pageIndex];
    const pageNumber = pageIndex + 1;

    this.showNotification(`重試載入第 ${pageNumber} 頁...`);

    // 滾動到該頁面
    outerPage.scrollIntoView({ behavior: 'smooth', block: 'center' });
    await new Promise(resolve => setTimeout(resolve, 500));

    // 等待 Canvas 載入
    const canvas = outerPage.querySelector('canvas.inner_page');
    if (canvas) {
      const isLoaded = await this.waitForCanvasLoad(canvas, pageNumber, 10000);

      if (isLoaded) {
        this.loadedPagesCount++;
      } else {
        // 仍然失敗，放回隊列末尾
        this.failedPages.push(pageIndex);
      }
    }

    // 發送更新的統計
    chrome.runtime.sendMessage({
      action: 'loadingStats',
      loadedPages: this.loadedPagesCount,
      currentPage: this.currentPage,
      totalPages: this.totalPages,
      failedCount: this.failedPages.length
    });

    // 如果沒有更多失敗頁面，發送完成消息
    if (this.failedPages.length === 0) {
      this.hideNotification();
      chrome.runtime.sendMessage({ action: 'allPagesLoaded' });
    } else {
      this.hideNotification();
    }
  }

  scrollToCaptcha() {
    // 查找驗證碼容器
    const captchaContainer = document.querySelector('.surplus-operate, #captcha_reading, #continueButton');

    if (captchaContainer) {
      captchaContainer.scrollIntoView({
        behavior: 'smooth',
        block: 'center'
      });

      // 高亮提示（可選）
      captchaContainer.style.outline = '3px solid #ff9800';
      captchaContainer.style.outlineOffset = '4px';
      setTimeout(() => {
        captchaContainer.style.outline = '';
        captchaContainer.style.outlineOffset = '';
      }, 2000);
    } else {
      this.showNotification('找不到驗證碼區域');
    }
  }

  // ==================== PDF Generation ====================
  async generatePDF(from = 1, to = null, exportType = 'range') {
    if (this.canvases.length === 0) {
      this.setState(State.ERROR);
      return;
    }

    this.setState(State.GENERATING);
    this.showNotification(chrome.i18n.getMessage('generating'));

    to = to || this.canvases.length;
    from = Math.max(1, Math.min(from, this.canvases.length));
    to = Math.max(from, Math.min(to, this.canvases.length));

    const selectedCanvases = this.canvases.slice(from - 1, to);
    const totalPages = this.canvases.length;

    try {
      const { jsPDF } = window.jspdf;
      if (!jsPDF) {
        throw new Error('jsPDF not loaded');
      }

      const firstCanvas = selectedCanvases[0];
      const pdfWidth = firstCanvas.width * 0.264583;
      const pdfHeight = firstCanvas.height * 0.264583;

      const pdf = new jsPDF({
        orientation: pdfHeight > pdfWidth ? 'portrait' : 'landscape',
        unit: 'mm',
        format: [pdfWidth, pdfHeight],
        compress: false
      });

      for (let i = 0; i < selectedCanvases.length; i++) {
        if (i > 0) {
          pdf.addPage([pdfWidth, pdfHeight]);
        }

        const canvas = selectedCanvases[i];
        const imgData = canvas.toDataURL('image/jpeg', this.quality);
        pdf.addImage(imgData, 'JPEG', 0, 0, pdfWidth, pdfHeight);

        // 發送 PDF 生成進度
        chrome.runtime.sendMessage({
          action: 'progressUpdate',
          source: 'pdf',
          exportType: exportType,
          current: i + 1,
          total: selectedCanvases.length
        });

        if (i % 5 === 0 && i > 0) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      }

      // 生成檔案名稱（優先使用 og:title meta 標籤）
      const ogTitle = document.querySelector('meta[property="og:title"]')?.content;
      const h1Title = document.querySelector('h1')?.textContent;
      const rawTitle = ogTitle || h1Title || 'document';

      // 清理檔案名稱
      const cleanTitle = rawTitle
        .trim()                                    // 移除首尾空白
        .replace(/[\s\u00A0\u200B\uFEFF]+/g, '_')  // 所有空白類字符轉底線
        .replace(/[\\/:*?"<>|]/g, '')              // 移除 Windows 不允許的檔名字符
        .replace(/_+/g, '_')                       // 連續底線合併為單一底線
        .replace(/^_+/, '')                        // 移除開頭底線
        .replace(/_+$/, '')                        // 移除結尾底線
        || 'document';

      // 如果輸出全部頁面（from=1 且 to=totalPages），不加頁數標記
      let filename;
      if (from === 1 && to === totalPages) {
        filename = `${cleanTitle}.pdf`;
      } else {
        filename = `${cleanTitle}_p${from}-${to}.pdf`;
      }

      pdf.save(filename);

      this.setState(State.READY);
      this.hideNotification();
      chrome.runtime.sendMessage({ action: 'generationComplete' });

    } catch (error) {
      this.setState(State.ERROR);
      this.showNotification(`${chrome.i18n.getMessage('error')}: ${error.message}`);
    }
  }

  // ==================== UI: Focus Mode ====================
  enableFocusMode() {
    if (this.focusModeEnabled) return;

    const pageContainer = this.detectPageContainer();
    if (!pageContainer) {
      return;
    }

    this.focusModeEnabled = true;
    this.hiddenElements = [];

    // 找到 pageContainer 的所有祖先元素
    const ancestors = new Set();
    let current = pageContainer;
    while (current && current !== document.body && current !== document.documentElement) {
      ancestors.add(current);
      current = current.parentElement;
    }
    ancestors.add(pageContainer);

    // 隱藏 body 的所有直接子元素（除了祖先鏈和通知）
    Array.from(document.body.children).forEach(child => {
      if (!ancestors.has(child) && child.id !== 'doc88-notification') {
        this.hiddenElements.push({
          element: child,
          originalDisplay: child.style.display
        });
        child.style.display = 'none';
      }
    });

    // 遞歸處理祖先元素的兄弟節點
    ancestors.forEach(ancestor => {
      if (ancestor.parentElement && ancestor.parentElement !== document.documentElement) {
        Array.from(ancestor.parentElement.children).forEach(sibling => {
          if (!ancestors.has(sibling) && sibling.id !== 'doc88-notification') {
            this.hiddenElements.push({
              element: sibling,
              originalDisplay: sibling.style.display
            });
            sibling.style.display = 'none';
          }
        });
      }
    });

    // 保存並設置背景
    this.originalBodyBg = document.body.style.background;
    this.originalBodyBgColor = document.body.style.backgroundColor;
    document.body.style.background = 'rgba(0, 0, 0, 0.65)';

    // 確保 pageContainer 有適當的背景
    this.originalContainerBg = pageContainer.style.background;
    if (!pageContainer.style.background && !window.getComputedStyle(pageContainer).background) {
      pageContainer.style.background = '#ffffff';
    }
  }

  disableFocusMode() {
    if (!this.focusModeEnabled) return;

    // 恢復所有隱藏的元素
    if (this.hiddenElements) {
      this.hiddenElements.forEach(({ element, originalDisplay }) => {
        element.style.display = originalDisplay;
      });
      this.hiddenElements = [];
    }

    // 恢復背景
    document.body.style.background = this.originalBodyBg || '';
    document.body.style.backgroundColor = this.originalBodyBgColor || '';

    const pageContainer = this.detectPageContainer();
    if (pageContainer && this.originalContainerBg !== undefined) {
      pageContainer.style.background = this.originalContainerBg;
    }

    this.focusModeEnabled = false;
  }

  // ==================== UI: Notification ====================
  showNotification(text) {
    if (!this.notification) {
      this.notification = document.createElement('div');
      this.notification.id = 'doc88-notification';
      document.body.appendChild(this.notification);
    }

    this.notification.textContent = text;
    this.notification.style.display = 'block';
  }

  hideNotification() {
    if (this.notification) {
      this.notification.style.display = 'none';
    }
  }

  // ==================== Page Info Update ====================
  updatePageInfo() {
    chrome.runtime.sendMessage({
      action: 'pageInfoUpdate',
      current: this.currentPage,
      total: this.totalPages
    });
  }

  // ==================== Monitoring ====================
  startMonitoring() {
    // Initial check
    this.checkUnlockStatus();

    // Setup MutationObserver
    this.observer = new MutationObserver(() => {
      this.checkUnlockStatus();
    });

    this.observer.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['style', 'class']
    });

    // Periodic check (0.5 秒間隔，確保即時響應)
    setInterval(() => {
      this.checkUnlockStatus();
      this.updatePageCount();
    }, 500);
  }

  checkUnlockStatus() {
    const hasContinueBtn = this.detectContinueButton();

    if (!this.isUnlocked && !hasContinueBtn) {
      this.isUnlocked = true;
      this.setState(State.UNLOCKED);
      chrome.runtime.sendMessage({ action: 'unlockComplete' });
    } else if (!this.isUnlocked && hasContinueBtn) {
      this.setState(State.WAITING_UNLOCK);
    }
  }

  updatePageCount() {
    if (!this.isLoading) {
      const current = this.detectCurrentPage();
      const total = this.detectTotalPages();

      if (current !== this.currentPage || total !== this.totalPages) {
        this.currentPage = current;
        this.totalPages = total;
        this.updatePageInfo();
      }
    }
  }

  // ==================== Message Handler ====================
  handleMessage(message, sender, sendResponse) {
    switch (message.action) {
      case 'getStatus':
        sendResponse({
          unlocked: this.isUnlocked,
          state: this.state,
          pageInfo: {
            current: this.currentPage,
            total: this.totalPages
          }
        });
        break;

      case 'startLoading':
        this.loadAllPages();
        this.notifyStateChange(); // Force broadcast
        sendResponse({ started: true });
        break;

      case 'stopLoading':
        this.stopLoading();
        this.notifyStateChange(); // Force broadcast
        sendResponse({ stopped: true });
        break;

      case 'generatePDF':
        this.generatePDF(message.from, message.to, message.exportType);
        sendResponse({ generating: true });
        break;

      case 'scrollToCaptcha':
        this.scrollToCaptcha();
        sendResponse({ scrolled: true });
        break;

      case 'retryLoadPage':
        this.retryNextFailedPage();
        sendResponse({ retrying: true });
        break;

      default:
        sendResponse({ error: 'Unknown action' });
    }

    return true;
  }

  // ==================== Initialization ====================
  async init() {
    // 檢查是否為文件瀏覽頁面
    if (!this.isDocumentViewPage()) {
      // 仍然監聽消息，但返回特殊狀態
      chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
        if (message.action === 'getStatus') {
          sendResponse({
            notDocumentPage: true,
            unlocked: false
          });
        } else {
          sendResponse({ error: 'Not a document view page' });
        }
        return true;
      });

      return; // 不啟動監測
    }

    // Load quality setting
    const { quality } = await chrome.storage.local.get('quality');
    if (quality) {
      this.quality = parseFloat(quality);
    }

    // Start monitoring
    this.startMonitoring();

    // Setup message listener
    chrome.runtime.onMessage.addListener(this.handleMessage.bind(this));
  }
}

// ==================== Start ====================
const controller = new Doc88Controller();
controller.init();
