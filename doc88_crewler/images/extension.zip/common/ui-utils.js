/**
 * Shared UI Utilities for Popup and Side Panel
 * Handles button state synchronization and common UI updates.
 */

const UI = {
  /**
   * Sets the button state to "Reload?" (Light Green)
   * Used when loading is complete (ready state).
   */
  setReloadButtonState() {
    const startBtn = document.getElementById('startLoadingBtn');
    const stopBtn = document.getElementById('stopLoadingBtn');
    
    if (startBtn) {
      startBtn.style.display = 'block';
      startBtn.textContent = '再重新載入？';
      startBtn.classList.remove('btn-primary');
      startBtn.classList.add('btn-reload');
      startBtn.disabled = false;
    }
    
    if (stopBtn) {
      stopBtn.style.display = 'none';
    }
  },

  /**
   * Sets the button state to "Loading..." (Stop Button Visible)
   * Used when loading is in progress.
   */
  setLoadingButtonState() {
    const startBtn = document.getElementById('startLoadingBtn');
    const stopBtn = document.getElementById('stopLoadingBtn');
    
    if (startBtn) {
      startBtn.style.display = 'none';
    }
    
    if (stopBtn) {
      stopBtn.style.display = 'block';
    }
  },

  /**
   * Sets the button state to "Start Loading" (Primary Color)
   * Used when idle or reset.
   */
  setIdleButtonState() {
    const startBtn = document.getElementById('startLoadingBtn');
    const stopBtn = document.getElementById('stopLoadingBtn');
    
    if (startBtn) {
      startBtn.style.display = 'block';
      startBtn.textContent = chrome.i18n.getMessage('startLoading');
      startBtn.classList.add('btn-primary');
      startBtn.classList.remove('btn-reload');
      startBtn.disabled = false;
    }
    
    if (stopBtn) {
      stopBtn.style.display = 'none';
    }
  }
};

// Export for use in modules or global scope if not using modules
if (typeof window !== 'undefined') {
  window.UI = UI;
}
