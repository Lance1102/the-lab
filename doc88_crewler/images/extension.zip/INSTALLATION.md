# Doc88 PDF Generator - 安裝指南

## 快速開始（5 分鐘）

### 第一步：準備圖示（可選）

如果想要自訂圖示：

1. 使用提供的 `icons/icon.svg` 作為設計基礎
2. 使用線上工具轉換為 PNG：
   - 訪問 https://svgtopng.com/
   - 上傳 `icon.svg`
   - 分別生成 16x16、48x48、128x128 的 PNG
   - 將它們重命名為 `icon16.png`、`icon48.png`、`icon128.png`
   - 放置到 `extension/icons/` 目錄

**或使用臨時佔位圖**（Windows + ImageMagick）：

```powershell
cd extension\icons
magick -size 16x16 xc:#4CAF50 icon16.png
magick -size 48x48 xc:#4CAF50 icon48.png
magick -size 128x128 xc:#4CAF50 icon128.png
```

詳見 `icons/ICON_GUIDE.md`

### 第二步：驗證 jsPDF 庫

確認 `extension/libs/jspdf.umd.min.js` 檔案存在：

```bash
# Windows
dir extension\libs\jspdf.umd.min.js

# macOS / Linux
ls -lh extension/libs/jspdf.umd.min.js
```

如果不存在，參考 `libs/LIBRARY_SETUP.md` 下載。

### 第三步：安裝到瀏覽器

#### Chrome 安裝

1. 開啟 Chrome 瀏覽器
2. 在網址列輸入：`chrome://extensions/`
3. 開啟右上角的「開發者模式」開關
4. 點擊左上角的「載入未封裝項目」按鈕
5. 選擇專案中的 `extension/` 資料夾
6. 點擊「選擇資料夾」
7. 擴展安裝完成！查看擴展列表應該會看到「Doc88 文件下載器」

#### Microsoft Edge 安裝

1. 開啟 Edge 瀏覽器
2. 在網址列輸入：`edge://extensions/`
3. 開啟左下角的「開發人員模式」開關
4. 點擊「載入解壓縮的擴充功能」按鈕
5. 選擇專案中的 `extension/` 資料夾
6. 點擊「選擇資料夾」
7. 擴展安裝完成！

### 第四步：測試擴展

1. 訪問任意 doc88.com 文檔頁面，例如：
   https://www.doc88.com/p-123456.html

2. 點擊瀏覽器工具列上的擴展圖示

3. 應該會看到控制面板顯示「等待驗證碼解鎖...」

4. 完成驗證碼後，狀態應該變為「解鎖完成，可以開始載入」

5. 點擊「開始載入頁面」按鈕測試功能

---

## 故障排除

### 問題 1：擴展無法載入

**可能原因**：

- Manifest 檔案格式錯誤
- 缺少必要檔案

**解決方案**：

1. 檢查 `extension/manifest.json` 是否存在
2. 確認所有引用的檔案都存在：
   
   ```bash
   # 必要檔案檢查清單
   extension/manifest.json               ✓
   extension/popup/popup.html            ✓
   extension/popup/popup.css             ✓
   extension/popup/popup.js              ✓
   extension/content/content.js          ✓
   extension/content/content.css         ✓
   extension/background/background.js    ✓
   extension/libs/jspdf.umd.min.js       ✓
   extension/_locales/zh_TW/messages.json ✓
   extension/_locales/en/messages.json   ✓
   ```

### 問題 2：點擊圖示沒有反應

**可能原因**：

- Popup 檔案路徑錯誤
- JavaScript 錯誤

**解決方案**：

1. 右鍵點擊擴展圖示 → 檢查彈出式視窗
2. 查看控制台是否有錯誤訊息
3. 檢查 `popup/popup.js` 是否有語法錯誤

### 問題 3：在 doc88.com 上沒有自動偵測

**可能原因**：

- Content script 未正確注入
- 域名匹配問題

**解決方案**：

1. 開啟 doc88.com 頁面
2. 按 F12 打開開發者工具
3. 切換到 Console 標籤
4. 查找 `[Doc88]` 開頭的日誌訊息
5. 如果沒有，檢查 `manifest.json` 中的 `content_scripts.matches` 配置

### 問題 4：jsPDF 未載入

**錯誤訊息**：`jsPDF is not defined`

**解決方案**：

1. 確認 `extension/libs/jspdf.umd.min.js` 存在
2. 檢查檔案大小（應該約 350 KB）
3. 如果檔案不存在或損壞，重新下載：
   
   ```bash
   cd extension/libs
   curl -o jspdf.umd.min.js https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js
   ```

### 問題 5：圖示不顯示

**可能原因**：

- PNG 圖示檔案不存在

**解決方案**：

1. 確認 `extension/icons/` 目錄下有 `icon16.png`、`icon48.png`、`icon128.png`
2. 使用臨時佔位圖（見「第一步」）
3. 或使用 SVG 轉 PNG 工具生成

---

## 更新擴展

當修改擴展代碼後：

1. 回到 `chrome://extensions/` 或 `edge://extensions/`
2. 找到「Doc88 文件下載器」
3. 點擊刷新按鈕（圓形箭頭圖示）
4. 重新載入使用擴展的頁面

---

## 解除安裝

1. 進入 `chrome://extensions/` 或 `edge://extensions/`
2. 找到「Doc88 文件下載器」
3. 點擊「移除」按鈕
4. 確認移除

---

## 發佈到 Chrome Web Store（可選）

如果想要發佈到 Chrome Web Store：

1. 準備發佈素材：
   
   - 128x128 圖示（已有）
   - 1280x800 或 640x400 截圖（至少 1 張）
   - 440x280 宣傳圖片（小）
   - 920x680 宣傳圖片（大，可選）
   - 1400x560 宣傳橫幅（可選）

2. 壓縮擴展目錄：
   
   ```bash
   cd extension
   zip -r ../doc88-extension.zip *
   ```

3. 訪問 Chrome Web Store Developer Dashboard：
   https://chrome.google.com/webstore/devconsole/

4. 支付 $5 一次性開發者註冊費

5. 上傳 `doc88-extension.zip`

6. 填寫商店資訊、描述、截圖

7. 提交審核（通常 1-3 天）

---

## 需要幫助？

- 查看主 README.md 了解功能詳情
- 查看 `icons/ICON_GUIDE.md` 了解圖示製作
- 查看 `libs/LIBRARY_SETUP.md` 了解庫設置
- 提交 Issue 到專案儲存庫

---

**祝您使用愉快！** 🎉
