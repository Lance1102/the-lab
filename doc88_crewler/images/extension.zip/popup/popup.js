/**
 * Doc88 PDF Generator - Popup Script
 * 控制擴展的 UI 邏輯和與 content script 的通信
 */

// ==================== i18n Support ====================
function loadI18n() {
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    const message = chrome.i18n.getMessage(key);
    if (message) {
      if (element.tagName === 'INPUT' || element.tagName === 'BUTTON') {
        element.value = message;
      } else {
        element.textContent = message;
      }
    }
  });
}

// ==================== Theme Management ====================
async function loadTheme() {
  const { theme } = await chrome.storage.local.get('theme');
  const isDark = theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.body.classList.toggle('dark-mode', isDark);
  return isDark;
}

async function toggleTheme() {
  const isDark = document.body.classList.toggle('dark-mode');
  await chrome.storage.local.set({ theme: isDark ? 'dark' : 'light' });
}

// ==================== Tab Detection ====================
async function getCurrentTab() {
  // 檢查是否為固定窗口
  const currentWindow = await chrome.windows.getCurrent();
  const { pinnedWindowId, pinnedTabId } = await chrome.storage.local.get(['pinnedWindowId', 'pinnedTabId']);

  if (currentWindow.id === pinnedWindowId && pinnedTabId) {
    // 如果是固定窗口，返回保存的標籤頁
    try {
      const tab = await chrome.tabs.get(pinnedTabId);
      return tab;
    } catch (e) {
      // 標籤頁已關閉，清理並返回當前活動標籤頁
      await chrome.storage.local.remove(['pinnedWindowId', 'pinnedTabId']);
    }
  }

  // 返回當前窗口的活動標籤頁
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isDoc88Domain(url) {
  return url && (url.includes('doc88.com') || url.includes('www.doc88.com'));
}

// ==================== UI Control ====================
function showInsideDoc88() {
  document.getElementById('outsideDoc88').style.display = 'none';
  document.getElementById('insideDoc88').style.display = 'flex';
}

function showOutsideDoc88(isDoc88Domain = false) {
  document.getElementById('insideDoc88').style.display = 'none';
  document.getElementById('outsideDoc88').style.display = 'flex';

  const emptyStateText = document.getElementById('emptyStateText');
  const emptyStateHint = document.getElementById('emptyStateHint');

  if (isDoc88Domain) {
    // 在 doc88.com 域，但不是文件頁面
    emptyStateText.textContent = chrome.i18n.getMessage('notDocumentPage');
    emptyStateHint.textContent = chrome.i18n.getMessage('notDocumentPageHint');
    emptyStateHint.style.display = 'block';
  } else {
    // 不在 doc88.com 域
    emptyStateText.textContent = '此擴展只在 Doc88.com 上可用';
    emptyStateHint.style.display = 'none';
  }
}

// ==================== Tab Switching ====================
function switchTab(tabName) {
  // Update tab buttons
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabName);
  });

  // Update tab contents
  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.toggle('active', content.dataset.tab === tabName);
  });

  // Update slider position
  const slider = document.querySelector('.tabs-slider');
  if (slider) {
    slider.dataset.active = tabName;
  }
}

function updateStatus(status, text) {
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const statusCard = document.getElementById('statusCard');
  const captchaAction = document.getElementById('captchaAction');

  statusDot.className = `status-dot status-${status}`;
  statusText.textContent = text;

  // 只在等待驗證碼狀態時將狀態卡片變為可點擊
  if (status === 'waiting' && (text.includes('驗證碼') || text.includes('CAPTCHA'))) {
    statusCard.classList.add('clickable');
    captchaAction.style.display = 'flex';
  } else {
    statusCard.classList.remove('clickable');
    captchaAction.style.display = 'none';
  }
}

function updatePageInfo(current, total, loaded) {
  document.getElementById('currentPage').textContent = current || '-';
  document.getElementById('totalPages').textContent = total || '-';

  // Update loaded pages count if provided
  const loadedPagesElement = document.getElementById('loadedPages');
  if (loaded !== undefined) {
    loadedPagesElement.textContent = loaded;

    // 載入過程中：只有文字變橘色作為動態視覺效果
    // clickable 狀態在 loadingComplete 時才加上
    if (current && loaded < current) {
      loadedPagesElement.classList.add('warning');
    } else {
      loadedPagesElement.classList.remove('warning');
    }
  }

  // Update page range inputs
  const pageFrom = document.getElementById('pageFrom');
  const pageTo = document.getElementById('pageTo');
  const rangeHint = document.getElementById('rangeHint');

  if (total) {
    pageFrom.max = total;
    pageTo.max = total;
    pageTo.value = total;
    rangeHint.textContent = chrome.i18n.getMessage('pageRangeHint', [total.toString()]);
  }
}

function updateProgress(current, total, targetButton = 'stopLoadingBtn') {
  const targetBtn = document.getElementById(targetButton);
  if (!targetBtn) return;

  const progressBg = targetBtn.querySelector('.btn-progress-bg');
  const progressText = targetBtn.querySelector('.btn-progress-text');

  if (current && total) {
    const percent = Math.round((current / total) * 100);
    if (progressBg) {
      progressBg.style.width = `${percent}%`;
    }
    if (progressText) {
      progressText.textContent = `${percent}% (${current}/${total})`;
    }
  } else {
    // 重置進度
    if (progressBg) {
      progressBg.style.width = '0%';
    }
    if (progressText) {
      progressText.textContent = '0% (0/0)';
    }
  }
}

// ==================== Page Range Validation ====================
function validatePageRange() {
  const pageFrom = document.getElementById('pageFrom');
  const pageTo = document.getElementById('pageTo');
  const totalPages = parseInt(document.getElementById('totalPages').textContent) || 1;

  let from = parseInt(pageFrom.value) || 1;
  let to = parseInt(pageTo.value) || totalPages;

  // Clamp values
  from = Math.max(1, Math.min(from, totalPages));
  to = Math.max(from, Math.min(to, totalPages));

  pageFrom.value = from;
  pageTo.value = to;

  return { from, to };
}

// ==================== Content Script Communication ====================
async function sendMessageToContent(action, data = {}) {
  const tab = await getCurrentTab();
  return chrome.tabs.sendMessage(tab.id, { action, ...data });
}

// ==================== UI Helpers ====================
function setReloadButtonState() {
  const startBtn = document.getElementById('startLoadingBtn');
  startBtn.style.display = 'block';
  startBtn.textContent = '再重新載入？';
  startBtn.classList.remove('btn-primary');
  startBtn.classList.add('btn-reload');
  document.getElementById('stopLoadingBtn').style.display = 'none';
}

// ==================== Event Handlers ====================
async function handleStartLoading() {
  UI.setLoadingButtonState();

  updateStatus('loading', chrome.i18n.getMessage('loading'));

  await sendMessageToContent('startLoading');
}

async function handleStopLoading() {
  UI.setIdleButtonState();

  await sendMessageToContent('stopLoading');
}

// Removed setReloadButtonState as it is now in UI utils

async function handleExportCurrent() {
  const current = parseInt(document.getElementById('currentPage').textContent) || 1;

  // 切換按鈕顯示
  const normalBtn = document.getElementById('exportCurrentBtn');
  const progressBtn = document.getElementById('exportCurrentBtnProgress');
  normalBtn.style.display = 'none';
  progressBtn.style.display = 'block';

  updateStatus('loading', chrome.i18n.getMessage('generating'));
  updateProgress(0, current, 'exportCurrentBtnProgress');

  await sendMessageToContent('generatePDF', {
    from: 1,
    to: current,
    exportType: 'current'
  });
}

async function handleExportRange() {
  const range = validatePageRange();

  // 切換按鈕顯示
  const normalBtn = document.getElementById('exportRangeBtn');
  const progressBtn = document.getElementById('exportRangeBtnProgress');
  normalBtn.style.display = 'none';
  progressBtn.style.display = 'block';

  updateStatus('loading', chrome.i18n.getMessage('generating'));
  updateProgress(0, range.to - range.from + 1, 'exportRangeBtnProgress');

  await sendMessageToContent('generatePDF', {
    from: range.from,
    to: range.to,
    exportType: 'range'
  });
}

async function handleGoToDoc88() {
  await chrome.tabs.create({ url: 'https://www.doc88.com' });
  window.close();
}

async function handleGoToCaptcha() {
  await sendMessageToContent('scrollToCaptcha');
  // 短暫延遲後關閉 popup，讓用戶看到跳轉效果
  setTimeout(() => {
    window.close();
  }, 300);
}

async function handlePinToggle() {
  const tab = await getCurrentTab();
  // Open Chrome Side Panel
  await chrome.sidePanel.open({ tabId: tab.id });
  window.close();
}

// ==================== Message Listener ====================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'statusUpdate':
      updateStatus(message.status, message.text);
      if (message.state === 'ready') {
        UI.setReloadButtonState();
      } else if (message.state === 'loading') {
        UI.setLoadingButtonState();
      }
      break;

    case 'pageInfoUpdate':
      updatePageInfo(message.current, message.total);
      break;

    case 'loadingStats':
      updatePageInfo(message.currentPage, message.totalPages, message.loadedPages);
      break;

    case 'progressUpdate':
      // 根據來源決定更新哪個按鈕的進度
      if (message.source === 'pdf') {
        // PDF 生成進度
        const exportType = message.exportType || 'range';
        const targetBtn = exportType === 'current' ? 'exportCurrentBtnProgress' : 'exportRangeBtnProgress';
        updateProgress(message.current, message.total, targetBtn);
      } else {
        // 頁面載入進度
        updateProgress(message.current, message.total, 'stopLoadingBtn');
      }
      break;

    case 'unlockComplete':
      updateStatus('ready', chrome.i18n.getMessage('unlockComplete'));
      document.getElementById('startLoadingBtn').disabled = false;
      break;

    case 'loadingComplete':
      updateStatus('ready', chrome.i18n.getMessage('complete'));
      UI.setReloadButtonState();
      // If there are incomplete pages, make the card clickable
      if (message.hasIncomplete) {
        document.getElementById('loadedPagesCard').classList.add('clickable');
      }
      break;

    case 'loadingStats':
      updatePageInfo(message.currentPage, message.totalPages, message.loadedPages);
      // Update clickable state based on failed count
      if (message.failedCount !== undefined) {
        const card = document.getElementById('loadedPagesCard');
        if (message.failedCount > 0) {
          card.classList.add('clickable');
        } else {
          card.classList.remove('clickable');
        }
      }
      break;

    case 'allPagesLoaded':
      document.getElementById('loadedPagesCard').classList.remove('clickable');
      updateStatus('ready', chrome.i18n.getMessage('complete') || '載入完成');
      UI.setReloadButtonState();
      break;

    case 'generationComplete':
      updateStatus('ready', chrome.i18n.getMessage('complete'));
      // 恢復輸出按鈕顯示
      document.getElementById('exportCurrentBtn').style.display = 'block';
      document.getElementById('exportCurrentBtnProgress').style.display = 'none';
      document.getElementById('exportRangeBtn').style.display = 'block';
      document.getElementById('exportRangeBtnProgress').style.display = 'none';
      // 重置進度
      updateProgress(null, null, 'exportCurrentBtnProgress');
      updateProgress(null, null, 'exportRangeBtnProgress');
      break;

    case 'error':
      updateStatus('error', message.text || chrome.i18n.getMessage('error'));
      // 恢復所有按鈕顯示
      document.getElementById('exportCurrentBtn').style.display = 'block';
      document.getElementById('exportCurrentBtnProgress').style.display = 'none';
      document.getElementById('exportRangeBtn').style.display = 'block';
      document.getElementById('exportRangeBtnProgress').style.display = 'none';
      updateProgress(null, null, 'stopLoadingBtn');
      updateProgress(null, null, 'exportCurrentBtnProgress');
      updateProgress(null, null, 'exportRangeBtnProgress');
      break;
  }

  sendResponse({ received: true });
  return true;
});

// ==================== Initialization ====================
async function init() {
  // Load i18n
  loadI18n();

  // Set tooltips - pin button now opens side panel
  document.getElementById('pinToggle').title = chrome.i18n.getMessage('openSidePanel') || '開啟側邊欄';

  // Load theme
  await loadTheme();

  // Setup theme toggle
  document.getElementById('themeToggle').addEventListener('click', toggleTheme);

  // Setup pin toggle (opens side panel)
  document.getElementById('pinToggle').addEventListener('click', handlePinToggle);

  // Check current tab
  const tab = await getCurrentTab();
  const isDoc88 = isDoc88Domain(tab.url);

  if (isDoc88) {
    // Setup tab switching
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        switchTab(btn.dataset.tab);
      });
    });

    // Setup event listeners
    document.getElementById('statusCard').addEventListener('click', (e) => {
      // 只在狀態卡片為可點擊狀態時觸發
      if (e.currentTarget.classList.contains('clickable')) {
        handleGoToCaptcha();
      }
    });
    document.getElementById('startLoadingBtn').addEventListener('click', handleStartLoading);
    document.getElementById('stopLoadingBtn').addEventListener('click', handleStopLoading);
    document.getElementById('exportCurrentBtn').addEventListener('click', handleExportCurrent);
    document.getElementById('exportRangeBtn').addEventListener('click', handleExportRange);

    // Click handler for retry loading failed pages
    document.getElementById('loadedPagesCard').addEventListener('click', (e) => {
      if (e.currentTarget.classList.contains('clickable')) {
        sendMessageToContent('retryLoadPage');
      }
    });

    // Page range validation
    document.getElementById('pageFrom').addEventListener('change', validatePageRange);
    document.getElementById('pageTo').addEventListener('change', validatePageRange);

    // Request current status from content script
    try {
      const response = await sendMessageToContent('getStatus');
      if (response) {
        // 檢查是否為非文件頁面
        if (response.notDocumentPage) {
          showOutsideDoc88(true); // true 表示在 doc88.com 域但不是文件頁
          // 不顯示「前往道客88」按鈕，因為已經在 doc88.com 了
          document.getElementById('goToDoc88').style.display = 'none';
          return;
        }

        // 是文件頁面，顯示控制面板
        showInsideDoc88();

        if (response.state === 'ready') {
          updateStatus('ready', chrome.i18n.getMessage('complete'));
          UI.setReloadButtonState();
        } else if (response.state === 'loading') {
          updateStatus('loading', chrome.i18n.getMessage('loading'));
          UI.setLoadingButtonState();
        } else if (response.unlocked) {
          updateStatus('ready', chrome.i18n.getMessage('unlockComplete'));
          document.getElementById('startLoadingBtn').disabled = false;
        }
        if (response.pageInfo) {
          updatePageInfo(response.pageInfo.current, response.pageInfo.total);
        }
      } else {
        // 沒有回應，可能是內容腳本未就緒
        showInsideDoc88();
      }
    } catch (e) {
      showInsideDoc88();
    }
  } else {
    showOutsideDoc88();
    document.getElementById('goToDoc88').addEventListener('click', handleGoToDoc88);
  }

  // Load quality setting
  const { quality } = await chrome.storage.local.get('quality');
  const qualitySelect = document.getElementById('qualitySelect');
  const qualityDisplay = document.getElementById('qualityDisplay');

  // Update display text based on value (use data-display for short text)
  function updateQualityDisplay() {
    const selectedOption = qualitySelect.options[qualitySelect.selectedIndex];
    if (qualityDisplay && selectedOption) {
      qualityDisplay.textContent = selectedOption.dataset.display || selectedOption.textContent;
    }
  }

  if (quality) {
    qualitySelect.value = quality;
  }
  updateQualityDisplay();

  // Save quality on change and update display
  qualitySelect?.addEventListener('change', async (e) => {
    await chrome.storage.local.set({ quality: e.target.value });
    updateQualityDisplay();
  });
}

// Start
init().catch(() => {});
