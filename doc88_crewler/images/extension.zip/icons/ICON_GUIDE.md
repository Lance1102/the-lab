# 圖示製作指南

## 需要的圖示尺寸

Chrome Extension 需要以下三個尺寸的圖示：
- `icon16.png` - 16x16 像素（工具列顯示）
- `icon48.png` - 48x48 像素（擴展管理頁面）
- `icon128.png` - 128x128 像素（Chrome Web Store）

## 設計建議

### 主題
- **概念**：PDF 文件 + 下載箭頭
- **配色**：綠色（#4CAF50）為主色，白色背景
- **風格**：現代、簡潔、扁平化

### 設計元素
1. **文件圖示**：簡單的 PDF 文件外框
2. **下載箭頭**：向下的箭頭表示下載動作
3. **數字 88**：代表 Doc88（可選）

## SVG 設計參考

```svg
<svg width="128" height="128" viewBox="0 0 128 128" xmlns="http://www.w3.org/2000/svg">
  <!-- Background Circle -->
  <circle cx="64" cy="64" r="60" fill="#4CAF50"/>

  <!-- Document Shape -->
  <path d="M 40 30 L 70 30 L 88 48 L 88 98 L 40 98 Z" fill="white"/>
  <path d="M 70 30 L 70 48 L 88 48" fill="none" stroke="white" stroke-width="2"/>

  <!-- Download Arrow -->
  <path d="M 64 50 L 64 80 M 54 70 L 64 80 L 74 70"
        fill="none" stroke="#4CAF50" stroke-width="4" stroke-linecap="round"/>

  <!-- PDF Text -->
  <text x="64" y="72" font-size="12" font-weight="bold"
        text-anchor="middle" fill="#4CAF50">PDF</text>
</svg>
```

## 線上工具建議

### 方法 1：使用線上 SVG 轉 PNG 工具
1. 將上述 SVG 代碼複製到 [SVG to PNG Converter](https://svgtopng.com/)
2. 分別生成 16x16、48x48、128x128 的 PNG 圖片
3. 下載並重命名為對應的檔名
4. 放置到 `extension/icons/` 目錄

### 方法 2：使用 Figma / Canva
1. 開啟 [Figma](https://www.figma.com/) 或 [Canva](https://www.canva.com/)
2. 建立 128x128 的畫布
3. 繪製上述設計
4. 匯出為 PNG，分別建立三個尺寸

### 方法 3：使用 GIMP / Photoshop
1. 開啟圖片編輯軟體
2. 建立新圖像（128x128，透明背景）
3. 使用形狀工具繪製設計
4. 分別縮放並匯出三個尺寸

## 快速生成（使用命令列）

如果您有 ImageMagick 或 Inkscape 安裝：

```bash
# 使用 Inkscape 從 SVG 生成 PNG
inkscape icon.svg -w 16 -h 16 -o icon16.png
inkscape icon.svg -w 48 -h 48 -o icon48.png
inkscape icon.svg -w 128 -h 128 -o icon128.png

# 或使用 ImageMagick
convert -size 128x128 -background transparent icon.svg icon128.png
convert icon128.png -resize 48x48 icon48.png
convert icon128.png -resize 16x16 icon16.png
```

## 臨時解決方案

如果暫時沒有圖示，可以先使用純色佔位圖：

```bash
# 在 extension/icons/ 目錄下執行
# Windows (需要 ImageMagick)
magick -size 16x16 xc:#4CAF50 icon16.png
magick -size 48x48 xc:#4CAF50 icon48.png
magick -size 128x128 xc:#4CAF50 icon128.png

# macOS/Linux (需要 ImageMagick)
convert -size 16x16 xc:#4CAF50 icon16.png
convert -size 48x48 xc:#4CAF50 icon48.png
convert -size 128x128 xc:#4CAF50 icon128.png
```

## 注意事項

- 確保圖示在淺色和深色背景下都清晰可見
- 16x16 的圖示要特別注意簡潔性（細節可能看不清）
- 建議使用透明背景（PNG 格式）
- 檔案大小盡量控制在 50KB 以內
