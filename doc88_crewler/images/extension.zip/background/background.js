/**
 * Doc88 PDF Generator - Background Service Worker
 * 管理擴展的生命週期和跨 tab 通信
 */

// ==================== Installation ====================
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    // First time installation
    chrome.storage.local.set({
      theme: 'light',
      quality: '1.0'
    });
  }
});

// ==================== Extension Icon Management ====================
// Update icon based on current tab
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    updateIconForTab(tab);
  } catch (e) {
    // Ignore icon update errors
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete') {
    updateIconForTab(tab);
  }
});

function updateIconForTab(tab) {
  if (!tab.url) return;

  const isDoc88 = tab.url.includes('doc88.com');

  // You can change icon opacity or color based on domain
  // For now, we keep it simple - icon is always visible
  // but functionality is limited outside doc88.com
}

// ==================== Message Handling ====================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  // Forward messages if needed
  // For now, most communication is direct between popup and content script
  sendResponse({ received: true });
  return true;
});

// ==================== Context Menu (Optional) ====================
// Uncomment to add right-click context menu
/*
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: 'doc88-generate-pdf',
    title: chrome.i18n.getMessage('generatePDF') || 'Generate PDF',
    contexts: ['page'],
    documentUrlPatterns: ['*://doc88.com/*', '*://www.doc88.com/*']
  });
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === 'doc88-generate-pdf') {
    chrome.tabs.sendMessage(tab.id, {
      action: 'generatePDF'
    });
  }
});
*/

// ==================== Keep Alive (Service Worker) ====================
// Service workers can be terminated by the browser
// Use this to keep the service worker alive if needed
let keepAliveInterval;

function keepAlive() {
  keepAliveInterval = setInterval(() => {
    chrome.runtime.getPlatformInfo(() => {
      // This keeps the service worker alive
    });
  }, 20000); // Every 20 seconds
}

// Start keep alive
keepAlive();

// Clean up on service worker termination
self.addEventListener('beforeunload', () => {
  if (keepAliveInterval) {
    clearInterval(keepAliveInterval);
  }
});
