# jsPDF 庫設置指南

## 自動下載（推薦）

在 `extension/libs/` 目錄下執行以下命令：

### Windows (PowerShell)
```powershell
Invoke-WebRequest -Uri "https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js" -OutFile "jspdf.umd.min.js"
```

### macOS / Linux
```bash
curl -o jspdf.umd.min.js https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js
```

### 使用 wget
```bash
wget -O jspdf.umd.min.js https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js
```

## 手動下載

1. 開啟瀏覽器訪問：
   https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js

2. 右鍵點擊頁面 → 另存為...

3. 將檔案命名為 `jspdf.umd.min.js`

4. 將檔案放置到 `extension/libs/` 目錄

## 驗證安裝

確認檔案存在：
```bash
# Windows
dir extension\libs\jspdf.umd.min.js

# macOS / Linux
ls -lh extension/libs/jspdf.umd.min.js
```

檔案大小應該約為 200-300 KB。

## 其他版本

如果需要使用其他版本的 jsPDF，請訪問：
https://cdnjs.com/libraries/jspdf

選擇版本後，複製 `jspdf.umd.min.js` 的 CDN 連結並下載。

## 許可證

jsPDF 使用 MIT License，可以自由使用於商業和非商業專案。
詳情請參閱：https://github.com/parallax/jsPDF
