/**
 * Doc88 PDF Generator - Side Panel Script
 * Side Panel UI 邏輯，與 popup.js 類似但適配 Side Panel 環境
 */

// ==================== i18n Support ====================
function loadI18n() {
  document.querySelectorAll('[data-i18n]').forEach(element => {
    const key = element.getAttribute('data-i18n');
    const message = chrome.i18n.getMessage(key);
    if (message) {
      if (element.tagName === 'INPUT' || element.tagName === 'BUTTON') {
        element.value = message;
      } else {
        element.textContent = message;
      }
    }
  });
}

// ==================== Theme Management ====================
async function loadTheme() {
  const { theme } = await chrome.storage.local.get('theme');
  const isDark = theme === 'dark' || (!theme && window.matchMedia('(prefers-color-scheme: dark)').matches);
  document.body.classList.toggle('dark-mode', isDark);
  return isDark;
}

async function toggleTheme() {
  const isDark = document.body.classList.toggle('dark-mode');
  await chrome.storage.local.set({ theme: isDark ? 'dark' : 'light' });
}

// ==================== Tab Detection ====================
async function getCurrentTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab;
}

function isDoc88Domain(url) {
  return url && (url.includes('doc88.com') || url.includes('www.doc88.com'));
}

// ==================== UI Control ====================
function showInsideDoc88() {
  document.getElementById('outsideDoc88').style.display = 'none';
  document.getElementById('insideDoc88').style.display = 'flex';
}

function showOutsideDoc88(isDoc88Domain = false) {
  document.getElementById('insideDoc88').style.display = 'none';
  document.getElementById('outsideDoc88').style.display = 'flex';

  const emptyStateText = document.getElementById('emptyStateText');
  const emptyStateHint = document.getElementById('emptyStateHint');

  if (isDoc88Domain) {
    emptyStateText.textContent = chrome.i18n.getMessage('notDocumentPage');
    emptyStateHint.textContent = chrome.i18n.getMessage('notDocumentPageHint');
    emptyStateHint.style.display = 'block';
  } else {
    emptyStateText.textContent = '此擴展只在 Doc88.com 上可用';
    emptyStateHint.style.display = 'none';
  }
}

// ==================== Tab Switching ====================
function switchTab(tabName) {
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabName);
  });

  document.querySelectorAll('.tab-content').forEach(content => {
    content.classList.toggle('active', content.dataset.tab === tabName);
  });

  const slider = document.querySelector('.tabs-slider');
  if (slider) {
    slider.dataset.active = tabName;
  }
}

function updateStatus(status, text) {
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const statusCard = document.getElementById('statusCard');
  const captchaAction = document.getElementById('captchaAction');

  statusDot.className = `status-dot status-${status}`;
  statusText.textContent = text;

  if (status === 'waiting' && (text.includes('驗證碼') || text.includes('CAPTCHA'))) {
    statusCard.classList.add('clickable');
    captchaAction.style.display = 'flex';
  } else {
    statusCard.classList.remove('clickable');
    captchaAction.style.display = 'none';
  }
}

function updatePageInfo(current, total, loaded) {
  document.getElementById('currentPage').textContent = current || '-';
  document.getElementById('totalPages').textContent = total || '-';

  const loadedPagesElement = document.getElementById('loadedPages');
  if (loaded !== undefined) {
    loadedPagesElement.textContent = loaded;

    // 載入過程中：只有文字變橘色作為動態視覺效果
    // clickable 狀態在 loadingComplete 時才加上
    if (current && loaded < current) {
      loadedPagesElement.classList.add('warning');
    } else {
      loadedPagesElement.classList.remove('warning');
    }
  }

  const pageFrom = document.getElementById('pageFrom');
  const pageTo = document.getElementById('pageTo');
  const rangeHint = document.getElementById('rangeHint');

  if (total) {
    pageFrom.max = total;
    pageTo.max = total;
    pageTo.value = total;
    rangeHint.textContent = chrome.i18n.getMessage('pageRangeHint', [total.toString()]);
  }
}

function updateProgress(current, total, targetButton = 'stopLoadingBtn') {
  const targetBtn = document.getElementById(targetButton);
  if (!targetBtn) return;

  const progressBg = targetBtn.querySelector('.btn-progress-bg');
  const progressText = targetBtn.querySelector('.btn-progress-text');

  if (current && total) {
    const percent = Math.round((current / total) * 100);
    if (progressBg) {
      progressBg.style.width = `${percent}%`;
    }
    if (progressText) {
      progressText.textContent = `${percent}% (${current}/${total})`;
    }
  } else {
    if (progressBg) {
      progressBg.style.width = '0%';
    }
    if (progressText) {
      progressText.textContent = '0% (0/0)';
    }
  }
}

// ==================== Page Range Validation ====================
function validatePageRange() {
  const pageFrom = document.getElementById('pageFrom');
  const pageTo = document.getElementById('pageTo');
  const totalPages = parseInt(document.getElementById('totalPages').textContent) || 1;

  let from = parseInt(pageFrom.value) || 1;
  let to = parseInt(pageTo.value) || totalPages;

  from = Math.max(1, Math.min(from, totalPages));
  to = Math.max(from, Math.min(to, totalPages));

  pageFrom.value = from;
  pageTo.value = to;

  return { from, to };
}

// ==================== Content Script Communication ====================
async function sendMessageToContent(action, data = {}) {
  const tab = await getCurrentTab();
  return chrome.tabs.sendMessage(tab.id, { action, ...data });
}

// ==================== Event Handlers ====================
async function handleStartLoading() {
  UI.setLoadingButtonState();

  updateStatus('loading', chrome.i18n.getMessage('loading'));

  await sendMessageToContent('startLoading');
}

async function handleStopLoading() {
  UI.setIdleButtonState();

  await sendMessageToContent('stopLoading');
}

// Removed setReloadButtonState as it is now in UI utils

async function handleExportCurrent() {
  const current = parseInt(document.getElementById('currentPage').textContent) || 1;

  const normalBtn = document.getElementById('exportCurrentBtn');
  const progressBtn = document.getElementById('exportCurrentBtnProgress');
  normalBtn.style.display = 'none';
  progressBtn.style.display = 'block';

  updateStatus('loading', chrome.i18n.getMessage('generating'));
  updateProgress(0, current, 'exportCurrentBtnProgress');

  await sendMessageToContent('generatePDF', {
    from: 1,
    to: current,
    exportType: 'current'
  });
}

async function handleExportRange() {
  const range = validatePageRange();

  const normalBtn = document.getElementById('exportRangeBtn');
  const progressBtn = document.getElementById('exportRangeBtnProgress');
  normalBtn.style.display = 'none';
  progressBtn.style.display = 'block';

  updateStatus('loading', chrome.i18n.getMessage('generating'));
  updateProgress(0, range.to - range.from + 1, 'exportRangeBtnProgress');

  await sendMessageToContent('generatePDF', {
    from: range.from,
    to: range.to,
    exportType: 'range'
  });
}

async function handleGoToCaptcha() {
  await sendMessageToContent('scrollToCaptcha');
}

// ==================== Message Listener ====================
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.action) {
    case 'statusUpdate':
      updateStatus(message.status, message.text);
      if (message.state === 'ready') {
        UI.setReloadButtonState();
      } else if (message.state === 'loading') {
        UI.setLoadingButtonState();
      }
      break;

    case 'pageInfoUpdate':
      updatePageInfo(message.current, message.total);
      break;

    case 'loadingStats':
      updatePageInfo(message.currentPage, message.totalPages, message.loadedPages);
      // Update clickable state based on failed count
      if (message.failedCount !== undefined) {
        const card = document.getElementById('loadedPagesCard');
        if (message.failedCount > 0) {
          card.classList.add('clickable');
        } else {
          card.classList.remove('clickable');
        }
      }
      break;

    case 'progressUpdate':
      if (message.source === 'pdf') {
        const exportType = message.exportType || 'range';
        const targetBtn = exportType === 'current' ? 'exportCurrentBtnProgress' : 'exportRangeBtnProgress';
        updateProgress(message.current, message.total, targetBtn);
      } else {
        updateProgress(message.current, message.total, 'stopLoadingBtn');
      }
      break;

    case 'unlockComplete':
      updateStatus('ready', chrome.i18n.getMessage('unlockComplete'));
      document.getElementById('startLoadingBtn').disabled = false;
      break;

    case 'loadingComplete':
      updateStatus('ready', chrome.i18n.getMessage('complete'));
      UI.setReloadButtonState();
      // If there are incomplete pages, make the card clickable
      if (message.hasIncomplete) {
        document.getElementById('loadedPagesCard').classList.add('clickable');
      }
      break;

    case 'allPagesLoaded':
      document.getElementById('loadedPagesCard').classList.remove('clickable');
      updateStatus('ready', chrome.i18n.getMessage('complete') || '載入完成');
      UI.setReloadButtonState();
      break;

    case 'generationComplete':
      updateStatus('ready', chrome.i18n.getMessage('complete'));
      document.getElementById('exportCurrentBtn').style.display = 'block';
      document.getElementById('exportCurrentBtnProgress').style.display = 'none';
      document.getElementById('exportRangeBtn').style.display = 'block';
      document.getElementById('exportRangeBtnProgress').style.display = 'none';
      updateProgress(null, null, 'exportCurrentBtnProgress');
      updateProgress(null, null, 'exportRangeBtnProgress');
      break;

    case 'error':
      updateStatus('error', message.text || chrome.i18n.getMessage('error'));
      document.getElementById('exportCurrentBtn').style.display = 'block';
      document.getElementById('exportCurrentBtnProgress').style.display = 'none';
      document.getElementById('exportRangeBtn').style.display = 'block';
      document.getElementById('exportRangeBtnProgress').style.display = 'none';
      updateProgress(null, null, 'stopLoadingBtn');
      updateProgress(null, null, 'exportCurrentBtnProgress');
      updateProgress(null, null, 'exportRangeBtnProgress');
      break;
  }

  sendResponse({ received: true });
  return true;
});

// ==================== Initialization ====================
async function init() {
  loadI18n();
  await loadTheme();

  document.getElementById('themeToggle').addEventListener('click', toggleTheme);

  const tab = await getCurrentTab();
  const isDoc88 = isDoc88Domain(tab?.url);

  if (isDoc88) {
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.addEventListener('click', () => {
        switchTab(btn.dataset.tab);
      });
    });

    document.getElementById('statusCard').addEventListener('click', (e) => {
      if (e.currentTarget.classList.contains('clickable')) {
        handleGoToCaptcha();
      }
    });
    document.getElementById('startLoadingBtn').addEventListener('click', handleStartLoading);
    document.getElementById('stopLoadingBtn').addEventListener('click', handleStopLoading);
    document.getElementById('exportCurrentBtn').addEventListener('click', handleExportCurrent);
    document.getElementById('exportRangeBtn').addEventListener('click', handleExportRange);

    // Click handler for retry loading failed pages
    document.getElementById('loadedPagesCard').addEventListener('click', (e) => {
      if (e.currentTarget.classList.contains('clickable')) {
        sendMessageToContent('retryLoadPage');
      }
    });

    document.getElementById('pageFrom').addEventListener('change', validatePageRange);
    document.getElementById('pageTo').addEventListener('change', validatePageRange);

    try {
      const response = await sendMessageToContent('getStatus');
      if (response) {
        if (response.notDocumentPage) {
          showOutsideDoc88(true);
          return;
        }

        showInsideDoc88();

        if (response.unlocked) {
          updateStatus('ready', chrome.i18n.getMessage('unlockComplete'));
          document.getElementById('startLoadingBtn').disabled = false;
        }
        
        if (response.state === 'ready') {
           UI.setReloadButtonState();
        } else if (response.state === 'loading') {
           updateStatus('loading', chrome.i18n.getMessage('loading'));
           UI.setLoadingButtonState();
        }
        if (response.pageInfo) {
          updatePageInfo(response.pageInfo.current, response.pageInfo.total);
        }
      } else {
        showInsideDoc88();
      }
    } catch (e) {
      showInsideDoc88();
    }
  } else {
    showOutsideDoc88();
  }

  const { quality } = await chrome.storage.local.get('quality');
  const qualitySelect = document.getElementById('qualitySelect');
  const qualityDisplay = document.getElementById('qualityDisplay');

  // Update display text based on value (use data-display for short text)
  function updateQualityDisplay() {
    const selectedOption = qualitySelect.options[qualitySelect.selectedIndex];
    if (qualityDisplay && selectedOption) {
      qualityDisplay.textContent = selectedOption.dataset.display || selectedOption.textContent;
    }
  }

  if (quality) {
    qualitySelect.value = quality;
  }
  updateQualityDisplay();

  // Save quality on change and update display
  qualitySelect?.addEventListener('change', async (e) => {
    await chrome.storage.local.set({ quality: e.target.value });
    updateQualityDisplay();
  });
}

init().catch(() => {});
